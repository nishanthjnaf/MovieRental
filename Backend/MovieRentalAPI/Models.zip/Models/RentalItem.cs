﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MovieRentalModels
{
    public class RentalItem : IComparable<RentalItem>, IEquatable<RentalItem>
    {
        public int Id { get; set; }
        public int RentalId { get; set; }
        public int InventoryId { get; set; }
        public decimal PricePerDay { get; set; }
        public int DaysRented { get; set; }
        public DateTime ReturnDate { get; set; }

        public Rental? Rental { get; set; }
        public Inventory? Inventory { get; set; }

        public int CompareTo(RentalItem? other)
        {
            return other != null ? Id.CompareTo(other.Id) : 1;
        }

        public bool Equals(RentalItem? other)
        {
            return other != null && Id == other.Id;
        }

        public override string ToString()
        {
            return $"Item Id: {Id}, RentalId: {RentalId}, Days: {DaysRented}";
        }
    }
}
