﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MovieRentalModels
{
    public class Inventory : IComparable<Inventory>, IEquatable<Inventory>
    {
        public int Id { get; set; }
        public int MovieId { get; set; }
        public int TotalCopies { get; set; }
        public int AvailableCopies { get; set; }
        public string Format { get; set; } = string.Empty;

        public Movie? Movie { get; set; }
        public ICollection<RentalItem>? RentalItems { get; set; }

        public int CompareTo(Inventory? other)
        {
            return other != null ? Id.CompareTo(other.Id) : 1;
        }

        public bool Equals(Inventory? other)
        {
            return other != null && Id == other.Id;
        }

        public override string ToString()
        {
            return $"Inventory Id: {Id}, MovieId: {MovieId}, Available: {AvailableCopies}";
        }
    }
}
