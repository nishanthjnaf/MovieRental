﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MovieRentalModels
{
    public class Payment : IComparable<Payment>, IEquatable<Payment>
    {
        public int Id { get; set; }
        public int RentalId { get; set; }
        public decimal Amount { get; set; }
        public string PaymentMethod { get; set; } = string.Empty;
        public DateTime PaymentDate { get; set; }

        public Rental? Rental { get; set; }

        public int CompareTo(Payment? other)
        {
            return other != null ? Id.CompareTo(other.Id) : 1;
        }

        public bool Equals(Payment? other)
        {
            return other != null && Id == other.Id;
        }

        public override string ToString()
        {
            return $"Payment Id: {Id}, Amount: {Amount}, Method: {PaymentMethod}";
        }
    }
}
